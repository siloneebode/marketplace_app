import 'package:first_project/config/constants.dart';
import 'package:flutter/material.dart';

class SocialButton extends StatelessWidget {
  String text;
  IconData icon;
  SocialButton({
    required this.text,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: double.infinity,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(7),
          border: Border.all(
            color: Colors.grey.shade400,
          )),
      child: Padding(
        padding:  EdgeInsets.symmetric(horizontal: 30),
        child: Row(
          children: [
            Icon(
              icon,
              color: Colors.grey.shade600,
            ),
            Spacer(),
            SizedBox(width: 15,),
            Text(
              'Continuer avec ${text}',
            ),
            Spacer(),
          ],
        ),
      ),
    );
  }
}
