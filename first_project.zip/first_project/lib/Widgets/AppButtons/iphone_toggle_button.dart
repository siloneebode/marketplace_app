import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';

class IphoneToggleButton extends StatefulWidget {
  const IphoneToggleButton({Key? key}) : super(key: key);

  @override
  State<IphoneToggleButton> createState() => _IphoneToggleButtonState();
}

class _IphoneToggleButtonState extends State<IphoneToggleButton> {

  bool value = false;
  bool isSwitchOn = false;

  bool _isStockLabel = false;
  void toggleStock(bool value) {
    if (_isStockLabel == false) {
      setState(() {
        _isStockLabel = true;
      });
    } else {
      setState(() {
        _isStockLabel = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
      scale: 0.8,
      child: FlutterSwitch(
        activeIcon: Icon(Icons.check),
        width: 55,
        activeColor: Colors.black,
        inactiveColor: Colors.grey.shade400,
        value: isSwitchOn,
        onToggle: (value) {
          setState(() {
            isSwitchOn = value;
          });
        },
      ),
    );
    //   Transform.scale(
    //     scale: 1,
    //     child:Switch(
    //       value: value,
    //       onChanged: (onChnaged){
    //         setState(() {
    //           value = onChnaged;
    //         });
    //       },
    //       activeTrackColor: Colors.black,
    //       activeColor: Colors.white,
    //       thumbIcon: MaterialStateProperty.resolveWith<Icon?>((Set<MaterialState> states) {
    //         if (states.contains(MaterialState.selected)) {
    //           return const Icon(Icons.check,color: Colors.black,);
    //         }
    //         return null; // All other states will use the default thumbIcon.
    //       }),
    //     )
    //     // CupertinoSwitch(
    //     //   onChanged: toggleStock,
    //     //   value: _isStockLabel,
    //     //   activeColor: Colors.grey.shade200,
    //     //   trackColor: Colors.black,
    //     //   thumbColor: Colors.orange,
    //     // ),
    // );
  }
}
