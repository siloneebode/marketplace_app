import 'package:flutter/material.dart';

import '../config/constants.dart';

class CustomTextField extends StatelessWidget {
  TextEditingController? controller;
  String? hintText;

  CustomTextField({
    required this.controller,
    required this.hintText,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: double.infinity,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(7),
          border: Border.all(
            color: Colors.grey.shade400,
          )),
      child: Padding(
        padding: EdgeInsets.only(left: kdPadding),
        child: TextField(
          controller: controller,
          decoration: InputDecoration(
            border: InputBorder.none,
            hintText: hintText,
          ),
        ),
      ),
    );
  }
}


class CustomTextField2 extends StatefulWidget {
  @override
  State<CustomTextField2> createState() => _CustomTextField2State();
}

class _CustomTextField2State extends State<CustomTextField2> {
  TextEditingController  _nameTextEditingController = TextEditingController();
  String? _labelText;

  @override
  Widget build(BuildContext context) {
    return Container(decoration: BoxDecoration(
      border: Border.all(
        color: Colors.grey
      ),
      borderRadius: BorderRadius.circular(7),
    ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: TextFormField(
          keyboardType: TextInputType.text,
          autofocus: false,
          textAlign: TextAlign.start,
                   onChanged: (v){
                     setState(() {
                       if(v.isNotEmpty){
                         _labelText = 'Name';
                       }else{
                         _labelText = null;
                       }
                     });

                   },
          textInputAction: TextInputAction.done,
          controller: _nameTextEditingController,
          style: TextStyle(
              color: Colors.black87,
              fontSize: 18,
              fontWeight: FontWeight.w500),
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: kdPadding),
            labelText: 'Name',
            hintStyle: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.w500),
            labelStyle: TextStyle(
                color: Colors.grey,
                fontSize: 18,
                fontWeight: FontWeight.w500),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }
}

