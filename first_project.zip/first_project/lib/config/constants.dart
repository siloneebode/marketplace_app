

const kdPadding = 16.0;