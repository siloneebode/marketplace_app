import 'package:first_project/config/constants.dart';
import 'package:flutter/material.dart';

class MessagePage extends StatefulWidget {
  const MessagePage({Key? key}) : super(key: key);

  @override
  State<MessagePage> createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage>
    with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    TabController _tabController = TabController(length: 2, vsync: this);
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: kdPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 40,
            ),
            Text(
              'Messages',
              style: TextStyle(
                color: Colors.black,
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            TabBar(
              isScrollable: true,
              labelStyle: TextStyle(fontWeight: FontWeight.bold),
              unselectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
              indicatorColor: Colors.black,
              controller: _tabController,
              unselectedLabelColor: Colors.grey.shade500,
              labelColor: Colors.black,
              tabs: <Widget>[
                Tab(
                  text: 'Messages',
                ),
                Tab(
                  text: 'Notifications',
                )
              ],
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    TabbarViewScreens(),
                    Center(
                      child: Text(
                        'There are No Notifications yet.',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TabbarViewScreens extends StatelessWidget {
  TabbarViewScreens({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView.builder(
          shrinkWrap: true,
          physics: BouncingScrollPhysics(),
          itemCount: recentTextList.length,
          itemBuilder: (BuildContext context, int index) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: 10,
              ),
              child: Column(
                children: [
                  Container(
                    height: 1,
                    width: double.infinity,
                    color: Colors.grey.shade400,
                  ),
                  SizedBox(height: 25,),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.black,
                        backgroundImage: AssetImage(
                          'assets/download.png',
                        ),
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Assistance Qasim',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w500
                              ),
                            ),
                            SizedBox(height: 5,),
                            Text(
                              'Bonjour Silone, Je vous contacte pour verifier I\'avancement de ce dossier et. This will help out team',
                              overflow: TextOverflow.ellipsis,maxLines: 2,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 17,),
                ],
              ),
            );
          }),
    );
  }

  List<String> recentTextList = [
    'next.js',
    'flutter',
    'django',
    'data engeniering',
    'eloquence',
    'machine learning',
  ];
}
