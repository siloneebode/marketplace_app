import 'package:first_project/View/bottom_navbar_pages/profile_detail_page.dart';
import 'package:first_project/config/constants.dart';
import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding:  EdgeInsets.symmetric(horizontal: kdPadding),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 40,
              ),
              Text(
                'Profil',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 30,
              ),
              InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfileDetailPage()));
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.black,
                      backgroundImage: AssetImage(
                        'assets/download.png'
                      ),
                      radius: 25,
                    ),
                    SizedBox(width: 10,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Silone',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black
                            ),
                          ),
                          Text(
                            'Afficher le profil',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                              fontWeight: FontWeight.w400
                            ),
                          ),
                        ],
                      ),
                    ),
                    Spacer(),
                    Icon(Icons.arrow_forward_ios_outlined,size: 17,),
                  ],
                ),
              ),
              SizedBox(height: 10,),
              Divider(
                color: Colors.grey.shade600,
              ),
              SizedBox(height: 10,),
              Text(
                'Parametres',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 23,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20,),
              _reusablaWidget(
                  (){},
                Icons.account_circle_outlined,
                'Informations personelles'
              ),
              SizedBox(height: 10,),
              _reusablaWidget(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et securite'
              ),
              SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),
              SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),SizedBox(height: 10,),
              _reusablaWidget2(
                      (){},
                  Icons.shield_outlined,
                  'Connexion et secur'
              ),
              SizedBox(height: 10,),
            ],
          ),
        ),
      ),
    );
  }
  Widget _reusablaWidget(void Function()? onTap,IconData? icon,String text){
    return InkWell(
      onTap: onTap,
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                icon,
                size: 25,
              ),
              SizedBox(width: 10,),
              Text(
                text,
                style: TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              Spacer(),
              Icon(
                Icons.arrow_forward_ios_outlined,size: 17,
              )
            ],
          ),
          SizedBox(height: 7,),
          Divider(
            color: Colors.grey.shade600,
          ),
        ],
      ),
    );
  }



  Widget _reusablaWidget2(void Function()? onTap,IconData? icon,String text){
    return InkWell(
      onTap: onTap,
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                icon,
                size: 25,
              ),
              SizedBox(width: 10,),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      text,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    SizedBox(height: 2,),
                    Text(
                      text,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  ],
                ),
              ),
              Spacer(),
              Icon(
                Icons.arrow_forward_ios_outlined,size: 17,
              )
            ],
          ),
          SizedBox(height: 7,),
          Divider(
            color: Colors.grey.shade600,
          ),
        ],
      ),
    );
  }
}
