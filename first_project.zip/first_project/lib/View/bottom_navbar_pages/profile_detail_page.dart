import 'package:first_project/Widgets/AppButtons/app_button.dart';
import 'package:first_project/config/constants.dart';
import 'package:flutter/material.dart';

import '../services_page.dart';

class ProfileDetailPage extends StatefulWidget {
  const ProfileDetailPage({Key? key}) : super(key: key);

  @override
  State<ProfileDetailPage> createState() => _ProfileDetailPageState();
}

class _ProfileDetailPageState extends State<ProfileDetailPage>
    with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    TabController _tabController = TabController(length: 3, vsync: this);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          children: [
            SizedBox(
              height: 25,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: kdPadding),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back_ios_new,
                      color: Colors.black,
                      size: 20,
                    ),
                  ),
                  Spacer(),
                  Text(
                    'Modifier',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            TabBar(
              labelStyle: TextStyle(fontWeight: FontWeight.bold),
              unselectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
              indicatorColor: Colors.black,
              controller: _tabController,
              unselectedLabelColor: Colors.grey.shade500,
              labelColor: Colors.black,
              tabs: <Widget>[
                Tab(
                  text: 'Closet',
                ),
                Tab(
                  text: 'Reviews',
                ),
                Tab(
                  text: 'About',
                ),
              ],
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    Closet(),
                    ReviewPage(),
                    Center(
                      child: Column(
                        children: [
                          Container(height: 2,width: double.infinity,color: Colors.grey.shade200,),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: kdPadding),
                            child: Text(
                              'There will be detail information given by the user.',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Spacer(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Closet extends StatelessWidget {
  const Closet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 2,
            width: double.infinity,
            color: Colors.grey.shade200,
          ),
          SizedBox(
            height: 25,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.blue,
                  child: Center(
                    child: Text(
                      'S',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'skattabugs',
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.w500,
                        fontSize: 20,
                      ),
                    ),
                    SizedBox(
                      height: 2,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.star,
                          color: Colors.yellow,
                          size: 20,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.yellow,
                          size: 20,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.yellow,
                          size: 20,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.yellow,
                          size: 20,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.yellow,
                          size: 20,
                        ),
                        Text(
                          '155',
                          style: TextStyle(color: Colors.grey.shade400),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 15,),
          Container(height: 2,width: double.infinity,color: Colors.grey.shade200,),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: kdPadding),
            child: Text.rich(TextSpan(children: <InlineSpan>[
              TextSpan(
                text:
                    'Bonjour comment vous allez? je vais bien je suis dans ce ton ajus 2lrbels yes yes je si skflsn ekenodenvrufid uiele oeoe... ',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 15,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              TextSpan(
                text: 'Afficher la suite',
                style:
                    TextStyle(decoration: TextDecoration.underline, fontSize: 15,fontWeight: FontWeight.bold,),
              ),
            ])),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              children: [
                Icon(
                  Icons.home,
                  color: Colors.black,
                ),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Text(
                    'Ma profession : Ingenieur Telecom',
                    style: TextStyle(color: Colors.black, fontSize: 14),
                    overflow: TextOverflow.ellipsis,
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              children: [
                Icon(
                  Icons.home,
                  color: Colors.black,
                ),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Text(
                    'Languages parlees : Anglais et Francais',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              children: [
                Icon(
                  Icons.home,
                  color: Colors.black,
                ),
                SizedBox(
                  width: 10,
                ),
                Text(
                  'Je visa : Yaounde Cameroun',
                  style: TextStyle(color: Colors.black, fontSize: 14),
                  overflow: TextOverflow.ellipsis,
                )
              ],
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.ac_unit_sharp,
                  color: Colors.black,
                  size: 15,
                ),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Text.rich(TextSpan(children: <InlineSpan>[
                    TextSpan(
                      text:
                          'TCertaines inform ations ont ete traduites automatiquement.',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 10,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    TextSpan(
                      text: 'Afficher la suite',
                      style: TextStyle(
                          decoration: TextDecoration.underline, fontSize: 12),
                    ),
                  ])),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Container(height: 2,width: double.infinity,color: Colors.grey.shade200,),
          SizedBox(height: 20,),
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(7),
                      border: Border.all(
                        color: Colors.grey.shade400,
                      )
                    ),
                    child: Padding(
                      padding:  EdgeInsets.symmetric(horizontal: kdPadding,vertical: kdPadding),
                      child: Center(
                        child: Text(
                          'Message',style: TextStyle(
                          color: Colors.grey.shade400,
                        ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 15,),
                Expanded(child: AppButton(text: 'Follow', buttoncolor: Colors.grey.shade400)),
              ],
            ),
          ),
          SizedBox(height: 20,),
          Container(height: 2,width: double.infinity,color: Colors.grey.shade200,),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: kdPadding),
            child: Text(
              '20 items',style: TextStyle(
              color: Colors.black,
              fontSize: 15,
            ),
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: kdPadding),
            child: Row(
              children: [
                Spacer(),
                Text(
                  'Sort by',style: TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                ),
                ),
                SizedBox(
                  width: 15,
                ),
                Text(
                  'All',style: TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
                ),
                Icon(Icons.arrow_drop_down,color: Colors.grey,),
              ],
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding:  EdgeInsets.symmetric(horizontal: kdPadding),
            child: GridView.builder(
              physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    childAspectRatio: 3 / 5.4,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 20),
                itemCount: 20,
                itemBuilder: (BuildContext ctx, index) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: 200,
                        width: double.infinity,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.amber,
                          image: DecorationImage(
                            image: AssetImage(
                              'assets/download.png',
                            ),
                            fit: BoxFit.cover,
                          )
                            ),
                      ),
                      SizedBox(height: 10,),
                      Row(
                        children: [
                          Text(
                            '\$20.00',style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),
                          ),
                          Spacer(),
                          Icon(Icons.favorite_border,color: Colors.grey,size: 15,),
                          SizedBox(width: 3,),
                          Text(
                            '27',style: TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                          ),
                        ],
                      ),
                      SizedBox(height: 4,),
                      Row(
                        children: [
                          Text(
                            '\$21.70 incl.',style: TextStyle(
                            color: Colors.green,
                            fontSize: 12,
                          ),
                          ),
                          SizedBox(width: 10,),
                          Icon(Icons.verified_outlined,color: Colors.green,size: 13,),
                        ],
                      ),
                      SizedBox(height: 6,),
                      Text(
                        '21/L',style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                      ),
                      SizedBox(height: 2,),
                      Text(
                        'Billabong',style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                      ),
                    ],
                  );
                }),
          ),
          SizedBox(
            height: 25,
          ),
        ],
      ),
    );
  }
}

class ReviewPage extends StatelessWidget {
  const ReviewPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(height: 2,width: double.infinity,color: Colors.grey.shade200,),
          SizedBox(height: 20,),
          ListView.builder(
            physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: 70,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                  padding:  EdgeInsets.symmetric(horizontal: kdPadding),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CircleAvatar(radius: 25,backgroundImage: AssetImage('assets/images.png'),),
                          SizedBox(width: 7,),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'keyrosewater',
                                      style: TextStyle(
                                        color: Colors.green.shade800,
                                        fontSize: 14,
                                      ),
                                    ),
                                    Spacer(),
                                    Text(
                                      '3 days ago',
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 2,),
                                Row(
                                  children: [
                                    Icon(Icons.star,color: Colors.yellow,size: 17,),
                                    Icon(Icons.star,color: Colors.yellow,size: 17,),
                                    Icon(Icons.star,color: Colors.yellow,size: 17,),
                                    Icon(Icons.star,color: Colors.yellow,size: 17,),
                                    Icon(Icons.star,color: Colors.yellow,size: 17,),
                                  ],
                                ),
                                SizedBox(height: 10,),
                                Text(
                                  'Incredible !! Shoes came looking even better than the pics. In love with them, Thanks so much !!',style: TextStyle(
                                  color: Colors.grey.shade500,
                                ),
                                )
                              ],
                            ),
                          ),

                        ],
                      ),
                      SizedBox(height: 15,),
                      Container(height: 2,width: double.infinity,color: Colors.grey.shade200,),
                      SizedBox(height: 20,),
                    ],
                  ),
                );
              }
          ),
        ],
      ),
    );
  }
}

