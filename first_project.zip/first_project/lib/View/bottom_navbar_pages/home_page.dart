import 'package:first_project/Widgets/AppButtons/app_button.dart';
import 'package:first_project/config/constants.dart';
import 'package:flutter/material.dart';

import 'filters_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 20,
            ),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: kdPadding),
              child: Card(
                color: Colors.white,
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Row(
                    children: [
                      Icon(
                        Icons.search,
                        color: Colors.black,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Destination',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            'N\'importe ou - Une semaine - Ajouter des',
                            style: TextStyle(
                              color: Colors.black,
                              overflow: TextOverflow.ellipsis,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>FiltersPage()));
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.grey.shade400
                            )
                          ),
                          height: 40,
                          width: 40,
                          child: Center(child: Icon(Icons.filter_alt)),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height*0.765,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(height: 20,),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal: kdPadding),
                      child: Container(
                        height: 141,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage(
                                'assets/download.png',
                              ),fit: BoxFit.cover,
                            )
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 10,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10,),
                              child: Text(
                                'Modifications des regles du catalogue',style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                              ),
                            ),
                            SizedBox(height: 5,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10,),
                              child: Text(
                                'Nous t\'invitons a prendre connaissance des regles du cataglogue mises a jour avant le 29 decembre2022.',style: TextStyle(
                                color: Colors.white,
                              ),
                              ),
                            ),
                            SizedBox(height: 12,),
                            AppButton(text: 'Voir les modifications', buttoncolor: Colors.grey)
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal: kdPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Favoris',style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                          ),
                          Text(
                            'Show all',style: TextStyle(
                            color: Colors.black,
                            fontSize: 12,
                          ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10,),
                    Padding(
                      padding:  EdgeInsets.only(left: kdPadding),
                      child: Container(
                        height: 263,
                        width: double.infinity,
                        child:  ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: 20,
                            separatorBuilder: (BuildContext context, int index) =>
                                SizedBox(width: 10,),
                            itemBuilder: (BuildContext context, int index) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    height: 200,
                                    width: 140,
                                    decoration: BoxDecoration(
                                      color: Colors.red,
                                      image: DecorationImage(
                                          image: AssetImage(
                                            'assets/download.png',
                                          ),
                                          fit: BoxFit.cover
                                      ),
                                    ),
                                    child: Padding(
                                      padding:  EdgeInsets.only(top: 160),
                                      child: Container(
                                        height: 40,
                                        width: double.infinity,
                                        color: Colors.grey.shade400,
                                        child: Padding(
                                          padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 13),
                                          child: Text(
                                            'Best Scene',style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 13,
                                          ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  Padding(
                                    padding:  EdgeInsets.symmetric(horizontal: 5),
                                    child: Row(
                                      children: [
                                        Text(
                                          '10.00 \$',style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                        ),
                                        SizedBox(width: 3,),
                                        Icon(
                                          Icons.assignment_late_rounded,size: 17,
                                        ),
                                        SizedBox(width: 40,),
                                        Icon(Icons.favorite,size: 17,color: Colors.red,),
                                        SizedBox(width: 2,),
                                        Text(
                                          '2',style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 10,
                                        ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:  EdgeInsets.symmetric(horizontal: 5),
                                    child: Text(
                                      'Quechua\n\$',style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 11,
                                    ),
                                    ),
                                  ),
                                ],
                              );
                            }),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal: kdPadding),
                      child: Text(
                        'Recommended for you',style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal: kdPadding),
                      child: GridView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 200,
                              childAspectRatio: 3 / 5.4,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 20),
                          itemCount: 20,
                          itemBuilder: (BuildContext ctx, index) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 200,
                                  width: double.infinity,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.amber,
                                      image: DecorationImage(
                                        image: AssetImage(
                                          'assets/images.png',
                                        ),
                                        fit: BoxFit.cover,
                                      )
                                  ),
                                ),
                                SizedBox(height: 10,),
                                Row(
                                  children: [
                                    Text(
                                      '\$20.00',style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 14,
                                    ),
                                    ),
                                    Spacer(),
                                    Icon(Icons.favorite_border,color: Colors.grey,size: 15,),
                                    SizedBox(width: 3,),
                                    Text(
                                      '27',style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 12,
                                    ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 4,),
                                Row(
                                  children: [
                                    Text(
                                      '\$21.70 incl.',style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 12,
                                    ),
                                    ),
                                    SizedBox(width: 10,),
                                    Icon(Icons.verified_outlined,color: Colors.green,size: 13,),
                                  ],
                                ),
                                SizedBox(height: 6,),
                                Text(
                                  '21/L',style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                                ),
                                SizedBox(height: 2,),
                                Text(
                                  'Billabong',style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                                ),
                              ],
                            );
                          }),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
