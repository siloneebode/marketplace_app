import 'package:first_project/Widgets/AppButtons/iphone_toggle_button.dart';
import 'package:flutter/material.dart';

import '../config/constants.dart';
import 'bottom_navbar_pages/message_page.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({Key? key}) : super(key: key);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> with TickerProviderStateMixin{
  @override
  Widget build(BuildContext context) {
    TabController _tabController = TabController(length: 2, vsync: this);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: kdPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 25,
              ),
              Icon(Icons.arrow_back,color: Colors.black,size: 20,),
              SizedBox(height: 30,),
              Text(
                'Notifications',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TabBar(
                isScrollable: true,
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                unselectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
                indicatorColor: Colors.black,
                controller: _tabController,
                unselectedLabelColor: Colors.grey.shade500,
                labelColor: Colors.black,
                tabs: <Widget>[
                  Tab(
                    text: 'Offres et mises a jour',
                  ),
                  Tab(
                    text: 'Compte',
                  )
                ],
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      FirstPage(),
                      Center(
                        child: Text(
                          'There are No Comptes yet.',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FirstPage extends StatefulWidget {
  const FirstPage({Key? key}) : super(key: key);

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 15,),
          Text(
            'Information et recompenses pour les hotes',style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
          ),
          SizedBox(height: 5,),
          Text(
            'Decouvrez les meilleurees pratiques en matiere d\'accuril de voyageurs et accedez a des avantages exclusiv\'s',style: TextStyle(
            color: Colors.grey,
            fontSize: 14,
          ),
          ),
          SizedBox(height: 15,),
          _reuseableRow('Reconnaissance et accomplissements','Active : Notifications push et apples telephoniques'),

          SizedBox(height: 45,),
          _reuseableRow('Informations et conseils','Active : Notifications push'),
          SizedBox(height: 45,),
          _reuseableRow('Tandences et suggestions de prix','Active : Notifications push'),
          SizedBox(height: 45,),
          _reuseableRow('Avantages pour les hotes','Active : Notifications push'),
        ],
      ),
    );
  }
  Widget _reuseableRow(String text1, text2){
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                text1,style: TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
              ),
              Text(
                text2,style: TextStyle(
                color: Colors.grey,
                fontSize: 14,
              ),
              ),
            ],
          ),
        ),
        SizedBox(width: 30,),
        InkWell(
          onTap: () {
            showModalBottomSheet(
              context: context,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10),
                    topLeft: Radius.circular(10)
                ),
              ),
              builder: (context) {
                return Padding(
                  padding:  EdgeInsets.symmetric(horizontal: kdPadding,vertical: 10),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20,),
                        Icon(Icons.close),
                        SizedBox(height: 40,),
                        Text(
                          'Reconnaissance et accomplissements',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                          ),
                        ),
                        SizedBox(height: 5,),
                        Text(
                          'Beneficiez d\'une reconnaissance pour avoir franchi des etapes importantes et obtenu le statut de Superhote.',style: TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                        ),
                        SizedBox(height: 10,),
                        _textToggle('Email'),
                        SizedBox(height: 10,),
                        _textToggle('Notifications push'),
                        SizedBox(height: 10,),
                        _textToggle('SMS'),
                        SizedBox(height: 10,),
                        _textToggle('Appels telephoniques'),
                       SizedBox(height: 15,),
                      ],
                    ),
                  ),
                );
              },
            );
          },
          child: Text(
            'Modifier',style: TextStyle(
            color: Colors.black,
            fontSize: 14,
            fontWeight: FontWeight.w500,
            decoration: TextDecoration.underline,
          ),
          ),
        )
      ],
    );
  }
  Widget _textToggle(String text){
    return Row(
      children: [
        Text(text,style: TextStyle(
          color: Colors.black,
          fontSize: 14,
        ),),
        Spacer(),
        IphoneToggleButton(),
      ],
    );
  }
}

