import 'package:first_project/Widgets/AppButtons/app_button.dart';
import 'package:first_project/config/constants.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../Widgets/AppButtons/social_button.dart';
import '../Widgets/textfield_widget.dart';

class LoginOrSignUpPage extends StatefulWidget {
  const LoginOrSignUpPage({Key? key}) : super(key: key);

  @override
  State<LoginOrSignUpPage> createState() => _LoginOrSignUpPageState();
}

class _LoginOrSignUpPageState extends State<LoginOrSignUpPage> {
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: kdPadding),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 20,
                ),
                Icon(
                  Icons.close,
                  color: Colors.black,
                ),
                SizedBox(
                  height: 15,
                ),
                Center(
                  child: Text(
                    'Connexion/Inscription',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                SizedBox(
                  height: 25,
                ),
                CustomTextField(
                  hintText: 'Enter username',
                  controller: _usernameController,
                ),
                SizedBox(
                  height: 15,
                ),
                CustomTextField(
                  hintText: 'Enter email',
                  controller: _passwordController,
                ),
                SizedBox(
                  height: 15,
                ),
                CustomTextField(
                  hintText: 'Enter password',
                  controller: _passwordController,
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Nous vous appellerons ou vous enverrons un SMS pour confirmer votre numero. Des frais standards d\'envoi de messages et d\'echange de donnees\'s appliquent.',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                AppButton(
                  text: 'Continuer',
                  buttoncolor: Colors.grey.shade400,
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 2,
                        color: Colors.grey.shade300,
                      ),
                    ),
                    SizedBox(width: 10,),
                    Text(
                      'OR',
                    ),
                    SizedBox(width: 10,),
                    Expanded(
                      child: Container(
                        height: 2,
                        color: Colors.grey.shade300,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                SocialButton(text: 'Facebook',icon: Icons.facebook,),
                SizedBox(
                  height: 15,
                ),
                SocialButton(text: 'Google',icon: FontAwesomeIcons.google,),
                SizedBox(
                  height: 15,
                ),
                SocialButton(text: 'Apple',icon: Icons.apple,),
                SizedBox(
                  height: 25,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
