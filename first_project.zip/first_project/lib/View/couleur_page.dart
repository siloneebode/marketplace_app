import 'package:flutter/material.dart';

import '../config/constants.dart';

class CouleurPage extends StatefulWidget {
  const CouleurPage({Key? key}) : super(key: key);

  @override
  State<CouleurPage> createState() => _CouleurPageState();
}

class _CouleurPageState extends State<CouleurPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 1,
        backgroundColor: Colors.white,
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        title: Text(
          'Couleur',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: kdPadding),
              child: Text(
                'Suggestions',
                style: TextStyle(color: Colors.grey),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: kdPadding),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.orange.shade100,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    'Creme',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 20,
                    width: 20,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.black
                      ),
                      borderRadius: BorderRadius.circular(5),
                    ),
                  ),

                ],
              ),
            ),
            SizedBox(height: 12,),
            Divider(
              color: Colors.grey,
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: kdPadding),
              child: Text(
                'Toutes les couleurs',
                style: TextStyle(color: Colors.grey),
              ),
            ),
            SizedBox(height: 10,),
            ListView.builder(
                shrinkWrap: true,
                physics: BouncingScrollPhysics(),
                itemCount: 10,
                itemBuilder: (BuildContext context, int index) {
                  return Column(
                    children: [
                      SizedBox(height: 12,),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: kdPadding),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 10,
                              backgroundColor: Colors.orange.shade100,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              'Creme',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Spacer(),
                            Container(
                              height: 20,
                              width: 20,
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.black
                                ),
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),

                          ],
                        ),
                      ),
                      SizedBox(height: 12,),
                      Divider(
                        color: Colors.grey,
                      ),
                    ],
                  );
                }),
          ],
        ),
      ),
    );
  }
}
