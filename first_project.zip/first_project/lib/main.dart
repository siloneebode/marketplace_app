import 'package:flutter/material.dart';

import 'View/accept_or_decline-page.dart';
import 'View/bottom_navbar_pages/main_bottombar_page.dart';
import 'View/detail_product_page.dart';
import 'View/login_or_signup_page.dart';
import 'View/notification_page.dart';
import 'View/payment_page.dart';
import 'View/services_page.dart';
import 'View/vends_ton_article_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: PaymentPage(),
    );
  }
}

